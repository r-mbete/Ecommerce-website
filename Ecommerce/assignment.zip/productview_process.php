<?php
require("connection.php");

$sql="SELECT FROM tbl_product product_name, product_description, unit_price, available_quantity,subcategory_id";
$result = mysqli_query($conn, $sql);

if (isset($_GET["edit"])){
    $id=$_GET["edit"];
    $sql="SELECT * FROM tbl_product WHERE product_id=$id";
    
    
}


?>