<html>

<head>
    <title>User Edit</title>
    <style>
    body {
        background-color: #dbcaca;
        font-family: poppins;
    }
    </style>
</head>


<link rel="stylesheet" type="text/css" href="styl.css" />

<link rel="website icon"
    href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSfl0noNtOx_iSpSPsAELHYG8M1jMH9p-_Tg&usqp=CAU"
    class="log">

<script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">

<body>
    <div class="table">
        <table>
            <thead>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Email Address</th>
                <th>Telephone Number</th>
                <th>Gender</th>
                <th>Role</th>
            </thead>

            <tbody>
                <?php
                        require_once("user_edit_process.php");
                        foreach($data as $key => $value){
                        ?>
                <tr>
                    <td><?php echo $value["first_name"] ?></td>
                    <td><?php echo $value["last_name"] ?></td>
                    <td><?php echo $value["email"] ?></td>
                    <td><?php echo $value["tel_number"] ?></td>
                    <td><?php echo $value["gender"] ?></td>
                    <td><?php echo $value["role"] ?></td>
                    <td><a href=user_edit_process.php?edit="<?php echo $value["user_id"] ?>">View</a></td>
                </tr>
                <?php}
                        ?>


            </tbody>
        </table>

    </div>


</body>

</html>