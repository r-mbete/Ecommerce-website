<?php
require("connection.php");

$sql="SELECT FROM tbl_users user_id, first_name, last_name, email, tel_number, gender, role";
$data=getData($sql);

if (isset($_GET["edit"])){
    $id=$_GET["edit"];
    $sql="SELECT * FROM tbl_users WHERE user_id=$id";
}

?>