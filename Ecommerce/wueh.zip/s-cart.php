<?php
require('connection.php');

 
 if(isset($_POST['update_cart'])){
    $update_quantity = $_POST['cart_quantity'];
    $update_id = $_POST['cart_id'];
    mysqli_query($conn, "UPDATE `tbl_cart` SET quantity = '$update_quantity' WHERE cart_id = '$update_id'") or die('query failed');
    $message[] = 'cart quantity updated successfully!';
 }
 
 if(isset($_GET['remove'])){
    $remove_id = $_GET['remove'];
    mysqli_query($conn, "DELETE FROM `tbl_cart` WHERE cart_id = '$remove_id'") or die('query failed');
    header('location:a-cart.php');
 }
   
 if(isset($_GET['delete_all'])){
    mysqli_query($conn, "DELETE FROM `tbl_cart` WHERE user_id = '$user_id'") or die('query failed');
    header('location:s-cart.php');
 }

?>
<html>

<head>
    <title>Shopping Cart</title>
    <style>
    body {
        background-color: #dbcaca;
        font-family: poppins;
    }

    .btn,
    .delete-btn,
    .option-btn {
        display: inline-block;
        padding: 10px 30px;
        cursor: pointer;
        font-size: 18px;
        color: #9f8888;
        border-radius: 5px;
        text-transform: capitalize;
    }

    .btn:hover,
    .delete-btn:hover,
    .option-btn:hover {
        background-color: #4f4747;
    }

    .btn {
        background-color: #5d5252;
        margin-top: 10px;
    }

    .delete-btn {
        background-color: var(--red);
    }

    .option-btn {
        background-color: #7d6a6a;
    }

    .container .shopping-cart {
        padding: 20px 0;
    }

    .container .shopping-cart table {
        width: 100%;
        text-align: center;
        border: var(--border);
        border-radius: 5px;
        box-shadow: var(--box-shadow);
        background-color: #9f8888;
    }

    .container .shopping-cart table thead {
        background-color: #5d5252;
    }

    .container .shopping-cart table thead th {
        padding: 10px;
        color: antiquewhite;
        text-transform: capitalize;
        font-size: 20px;
    }

    .container .shopping-cart table .table-bottom {
        background-color: #dbcaca;
    }

    .container .shopping-cart table tr td {
        padding: 10px;
        font-size: 20px;
        color: #342c2c;
    }

    .container .shopping-cart table tr td:nth-child(1) {
        padding: 0;
    }

    .container .shopping-cart table tr td input[type="number"] {
        width: 80px;
        border: var(--border);
        padding: 12px 14px;
        font-size: 20px;
        color: #342c2c;
    }

    .container .shopping-cart .cart-btn {
        margin-top: 10px;
        text-align: center;
    }

    .container .shopping-cart .disabled {
        pointer-events: none;
        background-color: var(--red);
        opacity: .5;
        user-select: none;
    }
    </style>
</head>

<link rel="stylesheet" type="text/css" href="styl.css" />

<link rel="website icon"
    href="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSSfl0noNtOx_iSpSPsAELHYG8M1jMH9p-_Tg&usqp=CAU"
    class="log">

<script src="https://kit.fontawesome.com/c8e4d183c2.js" crossorigin="anonymous"></script>

<link rel="preconnect" href="https://fonts.googleapis.com">
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
<link href="https://fonts.googleapis.com/css2?family=Poppins:wght@200&display=swap" rel="stylesheet">

<body>
    <div class="container">
        <div class="shopping-cart">
            <h2 id="cate">Shopping Cart</h2>
            <table>
                <thead>
                    <th>Image</th>
                    <th>Name</th>
                    <th>Price</th>
                    <th>Quantity</th>
                    <th>Total Price</th>
                    <th></th>
                </thead>

                <tbody>
                    <?php
        $cart = mysqli_query($conn, "SELECT * FROM tbl_order");
        if(mysqli_num_rows($cart) >= 0){
        while($fetch_cart = mysqli_fetch_assoc($cart)){
        ?>
                    <tr>
                        <td><img src="upload/<?php echo $fetch_cart['image']; ?>" height="100" alt=""></td>
                        <td><?php echo $fetch_cart['produc_name']; ?></td>
                        <td>$<?php echo $fetch_cart['unit_price']; ?>/-</td>
                        <td>
                            <form action="" method="post">
                                <input type="hidden" name="cart_id" value="<?php echo $fetch_cart['cart_id']; ?>">
                                <input type="number" min="1" name="cart_quantity"
                                    value="<?php echo $fetch_cart['quantity']; ?>">
                                <input type="submit" name="update_cart" value="update" class="option-btn">
                            </form>
                        </td>
                        <td>$<?php echo $sub_total = ($fetch_cart['unit_price'] * $fetch_cart['quantity']); ?>/-</td>
                        <td><a href="index.php?remove=<?php echo $fetch_cart['cart_id']; ?>" class="delete-btn"
                                onclick="return confirm('remove item from cart?');">Remove</a></td>
                    </tr>
                    <?php
         //$grand_total += $sub_total;
            }
         }else{
            echo '<tr><td style="padding:20px; text-transform:capitalize;" colspan="6">no item added</td></tr>';
         }
      ?>
                    <tr class="table-bottom">
                        <td colspan="4">Grand total :</td>
                        <td>KES.<?php //echo $grand_total; ?>/-</td>
                        <td><a href="index.php?delete_all" onclick="return confirm('Delete all from cart?');"
                                class="delete-btn <?php echo ($grand_total > 1)?'':'disabled'; ?>">Delete All</a></td>
                    </tr>
                </tbody>
            </table>

            <div class="cart-btn">
                <a href="#" class="btn 
                <?php 
                //echo ($grand_total > 1)?'':'disabled'; 
                ?> ">Proceed to Checkout</a>
            </div>
            <div class="cart-btn">
                <a href="index.php" class="btn">Back to Home Page</a>
            </div>
        </div>
    </div>
</body>

</html>